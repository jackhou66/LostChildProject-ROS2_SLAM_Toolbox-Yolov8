# Childeren or human detector > 2023-05-28 9:00pm
https://universe.roboflow.com/robotprogramming/childeren-or-human-detector

Provided by a Roboflow user
License: CC BY 4.0

